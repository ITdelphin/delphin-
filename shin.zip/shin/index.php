<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle contact form submission
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $to = 'akezaritha12@gmail.com';
    $subject = 'New Contact Message from ' . $name;
    $headers = 'From: ' . $email . "\r\n" .
               'Reply-To: ' . $email . "\r\n" .
               'X-Mailer: PHP/' . phpversion();

    if (mail($to, $subject, $message, $headers)) {
        $_SESSION['message'] = "Your message has been sent successfully!";
    } else {
        $_SESSION['error'] = "Failed to send message. Please try again.";
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shine Car Wash</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
            position: relative;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline-block;
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
        }

        .contact-form {
            display: none;
            position: absolute;
            top: 60px;
            right: 20px;
            background-color: white;
            color: black;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 300px;
            z-index: 1000;
        }

        .contact-form input, .contact-form textarea {
            width: 100%;
            margin: 8px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }

        .hero {
            background-color: #4CAF50;
            color: white;
            padding: 50px 0;
            text-align: center;
        }

        .services-container {
            text-align: center;
            padding: 20px;
        }

        .services {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .service {
            background: white;
            padding: 20px;
            margin: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 30%;
            min-width: 250px;
        }

        .order-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .order-btn:hover {
            background-color: #45a049;
        }

        .message {
            text-align: center;
            padding: 10px;
            margin: 10px auto;
            border-radius: 5px;
            max-width: 500px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }

        footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: 40px;
        }

        .social a {
            color: white;
            margin: 0 10px;
            text-decoration: none;
        }

        .social a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="service.php">Services</a></li>
                <li><a href="#" onclick="toggleContactForm()">Contact Us</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
        <!-- Contact form in header -->
        <div id="contactForm" class="contact-form">
            <h3>Contact Us</h3>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" rows="4" placeholder="Your Message" required></textarea>
                <button type="submit" class="submit-btn">Send</button>
            </form>
        </div>
    </header>

    <main>
        <section class="hero">
            <h1>Welcome to Shine Car Wash</h1>
            <p>Your car deserves the best care.</p>
        </section>

        <?php
        if (isset($_SESSION['message'])) {
            echo '<div class="message success">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
        }
        if (isset($_SESSION['error'])) {
            echo '<div class="message error">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>

        <section class="services-container">
            <h2>Our Services</h2>
            <div class="services">
                <div class="service">
                    <h3>Basic Wash</h3>
                    <p>Exterior cleaning only.</p>
                    <h2>$10</h2>
                    <a href="order.php?service=Basic+Wash&price=10" class="order-btn">Order Now</a>
                </div>
                <div class="service">
                    <h3>Deluxe Wash</h3>
                    <p>Exterior and interior cleaning.</p>
                    <h2>$20</h2>
                    <a href="order.php?service=Deluxe+Wash&price=20" class="order-btn">Order Now</a>
                </div>
                <div class="service">
                    <h3>Premium Wash</h3>
                    <p>Full detailing service.</p>
                    <h2>$30</h2>
                    <a href="order.php?service=Premium+Wash&price=30" class="order-btn">Order Now</a>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="social">
            <a href="https://wa.me/+250790405655" target="_blank">WhatsApp</a>
            <a href="https://facebook.com/ngdelphin" target="_blank">Facebook</a>
            <a href="mailto:ip.patient4@gmail.com">Email us</a>
        </div>
        <p>&copy; 2025 Shine Car Wash</p>
    </footer>

    <script>
        function toggleContactForm() {
            const form = document.getElementById('contactForm');
            form.style.display = (form.style.display === 'block') ? 'none' : 'block';
        }

        document.addEventListener('click', function (event) {
            const form = document.getElementById('contactForm');
            if (!form.contains(event.target) && !event.target.matches('a[onclick*="toggleContactForm"]')) {
                form.style.display = 'none';
            }
        });
    </script>
</body>
</html>