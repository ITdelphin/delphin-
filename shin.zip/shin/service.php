<?php

?>

<html>
  <title>Services - Shine Car Wash</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: #f4f4f4;
    }

    header {
      background: #333;
      color: #fff;
      padding: 10px 0;
      text-align: center;
    }

    nav ul {
      list-style: none;
      padding: 0;
    }

    nav ul li {
      display: inline;
      margin: 0 15px;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
    }

    main {
      padding: 20px;
      max-width: 1000px;
      margin: auto;
    }

    h2 {
      text-align: center;
    }

    .services-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
    }

    .service-box {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      margin: 20px;
      padding: 20px;
      width: 250px;
      text-align: center;
      cursor: pointer;
      transition: transform 0.3s ease;
    }

    .service-box:hover {
      transform: translateY(-5px);
      background-color: #e6f7ff;
    }

    .service-details {
      display: none;
      background: #ffffff;
      border-radius: 8px;
      padding: 15px;
      margin-top: 10px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      animation: fadeIn 0.3s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    footer {
      background: #333;
      color: white;
      text-align: center;
      padding: 10px 0;
      margin-top: 40px;
    }
  </style>
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="service.php">Services</a></li>
        <li><a href="contact.php">Contact Us</a></li>
        <li><a href="login.php">Logout</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <h2>Our Car Wash Services</h2>
    <div class="services-grid">
      <div class="service-box" onclick="toggleDetails('basic')">
        <h3>Basic Wash</h3>
        <p>$10</p>
        <div id="basic" class="service-details">
          <p><strong>Description:</strong> Exterior car wash including wheels and windows.</p>
          <p><strong>Tools Used:</strong></p>
          <ul>
            <li>Pressure Washer</li>
            <li>Foam Cannon</li>
            <li>Microfiber Cloth</li>
          </ul>
        </div>
      </div>

      <div class="service-box" onclick="toggleDetails('deluxe')">
        <h3>Deluxe Wash</h3>
        <p>$20</p>
        <div id="deluxe" class="service-details">
          <p><strong>Description:</strong> Exterior + interior vacuum and wipe-down.</p>
          <p><strong>Tools Used:</strong></p>
          <ul>
            <li>Vacuum Cleaner</li>
            <li>Dashboard Polish</li>
            <li>Glass Cleaner</li>
            <li>Wheel Brush</li>
          </ul>
        </div>
      </div>

      <div class="service-box" onclick="toggleDetails('premium')">
        <h3>Premium Wash</h3>
        <p>$30</p>
        <div id="premium" class="service-details">
          <p><strong>Description:</strong> Full detailing including wax, engine cleaning, and deep interior care.</p>
          <p><strong>Tools Used:</strong></p>
          <ul>
            <li>Steam Cleaner</li>
            <li>Orbital Polisher</li>
            <li>Leather Conditioner</li>
            <li>Detailing Brushes</li>
          </ul>
        </div>
      </div>
    </div>
  </main>

  <footer>
    <p>&copy; 2025 Shine Car Wash. All Rights Reserved.</p>
  </footer>

  <script>
    function toggleDetails(id) {
      const detail = document.getElementById(id);
      const allDetails = document.querySelectorAll('.service-details');

      allDetails.forEach(d => {
        if (d !== detail) d.style.display = 'none';
      });

      detail.style.display = detail.style.display === 'block' ? 'none' : 'block';
    }
  </script>
</body>
</html>
