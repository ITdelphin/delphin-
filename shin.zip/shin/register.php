<?php
$conn= mysqli_connect("localhost", "root", "", "shine_car_wash");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $craete = mysqli_query($conn, "INSERT INTO users VALUES ('', '$name','$email', '$username','$password')");
    if ($craete) {
        echo"<script>alert('Registration successful! You can now log in.');</script>";   
    }

}
?>
<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}


main {
    width: 100%;
    max-width: 400px;
    background: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}


.login h2, .register h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}


.login form,
.register form {
    display: flex;
    flex-direction: column;
}

.login label,
.register label {
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.login input,
.register input {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.login button,
.register button {
    padding: 10px;
    background-color: #007BFF;
    color: #fff;
    border: none;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.login button:hover,
.register button:hover {
    background-color: #0056b3;
}

.login p,
.register p {
    text-align: center;
    margin-top: 15px;
}

.login a,
.register a {
    color: #007BFF;
    text-decoration: none;
}

.login a:hover,
.register a:hover {
    text-decoration: underline;
}


.error {
    color: red;
    font-size: 14px;
    margin-bottom: 15px;
    text-align: center;
}

</style>


<html >
<head>
    <meta charset="UTF-8">
  
    <title>Register - Shine Car Wash</title>
  
</head>
<body>
    <main>
        <section class="register">
            <h2>Register</h2>
            <form action="register.php" method="POST">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" required>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Register</button>
            </form>
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </section>
    </main>
</body>
</html>