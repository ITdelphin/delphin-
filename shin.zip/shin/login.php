<?php
$conn= mysqli_connect("localhost", "root", "", "shine_car_wash");

if (isset($_POST["pass"])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $select = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' AND password='$pass'");
    if (mysqli_num_rows($select) > 0) {
        
        header("Location: index.php");
        exit(); 
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}


main {
    width: 100%;
    max-width: 400px;
    background: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
}


.login h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

.login form {
    display: flex;
    flex-direction: column;
}

.login label {
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.login input {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.login button {
    padding: 10px;
    background-color:rgb(201, 57, 69);
    color: #fff;
    border: none;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.login button:hover {
    background-color:rgb(84, 86, 88);
}

.login p {
    text-align: center;
    margin-top: 15px;
}

.login a {
    color: #007BFF;
    text-decoration: none;
}

.login a:hover {
    text-decoration: underline;
}


.del {
    color: red;
    font-size: 14px;
    margin-bottom: 15px;
    text-align: center;
}

</style>


<html>
<head>

    <title>Login - Shine Car Wash</title>
</head>
<body>
    <main>
        <section class="login">
            <h2>Login</h2>
            <?php if (isset($error)): ?>
                <p class="del"><?= $error ?></p>
            <?php endif; ?>
            <form action="" method="POST">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <button type="submit" name="pass">Login</button>
            </form>
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </section>
    </main>
</body>
</html>