<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serviceType = $_POST['serviceType'];
    $servicePrice = $_POST['servicePrice'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $carModel = $_POST['carModel'];
    $carLicense = $_POST['carLicense'];
    $specialInstructions = $_POST['specialInstructions'];
    $feedback = $_POST['feedback'];
    $workContact = $_POST['workContact'] ?? '';
    $clientLocation = $_POST['clientLocation'] ?? ''; 
    $appointmentDate = $_POST['appointmentDate'] ?? '';
    $appointmentTime = $_POST['appointmentTime'] ?? '';


    $workContacts = [
        'Delphin' => '024567666776',
        'Patient' => '5365778890234567',
        'Ritha' => '23456789'
    ];

    $workPhone = isset($workContacts[$workContact]) ? $workContacts[$workContact] : '';

    $to = 'akezaritha12@gmail.com';
    $subject = "New Car Wash Order: $serviceType";
    $message = "
    <html>
    <head><title>New Car Wash Order</title></head>
    <body>
        <h2>New Order Details</h2>
        <p><strong>Service Type:</strong> $serviceType</p>
        <p><strong>Price:</strong> $$servicePrice</p>
        <p><strong>Customer Name:</strong> $name</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
        <p><strong>Appointment Date:</strong> $appointmentDate</p>
        <p><strong>Appointment Time:</strong> $appointmentTime</p>
        <p><strong>Work Contact:</strong> $workContact</p>
        <p><strong>Work Phone:</strong> $workPhone</p>
        <p><strong>Client Location:</strong> $clientLocation</p>
        <p><strong>Car Model:</strong> $carModel</p>
        <p><strong>License Plate:</strong> $carLicense</p>
        <p><strong>Special Instructions:</strong> $specialInstructions</p>
        <p><strong>Customer Feedback:</strong> $feedback</p>
    </body>
    </html>";

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: $email\r\n";

    if (mail($to, $subject, $message, $headers)) {
        $_SESSION['message'] = "Thank you for your order! We will contact you soon.";
    } else {
        $_SESSION['error'] = "There was an error submitting your order. Please try again.";
    }

    header("Location: index.php");
    exit();
}

// Get service details from URL
$serviceType = isset($_GET['service']) ? htmlspecialchars($_GET['service']) : '';
$servicePrice = isset($_GET['price']) ? htmlspecialchars($_GET['price']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Service - Shine Car Wash</title>
    <style>
    body {
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
        color: #333;
        line-height: 1.6;
    }
    
    header {
        background-color: #333;
        color: white;
        padding: 15px 0;
        text-align: center;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    nav ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        justify-content: center;
    }
    
    nav ul li {
        margin: 0 15px;
    }
    
    nav ul li a {
        color: white;
        text-decoration: none;
        font-weight: 500;
        transition: color 0.3s;
    }
    
    nav ul li a:hover {
        color: #4CAF50;
    }
    
    .order-form {
        max-width: 600px;
        margin: 30px auto;
        padding: 25px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }
    
    .order-form h2 {
        color: #4CAF50;
        text-align: center;
        margin-bottom: 20px;
    }
    
    .order-form h3 {
        color: #333;
        margin-top: 20px;
        margin-bottom: 10px;
        font-size: 18px;
    }
    
    .order-form input,
    .order-form select,
    .order-form textarea {
        width: 100%;
        padding: 12px;
        margin: 8px 0 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 16px;
        transition: border 0.3s;
    }
    
    .order-form input:focus,
    .order-form select:focus,
    .order-form textarea:focus {
        border-color: #4CAF50;
        outline: none;
    }
    
    .order-form select {
        height: 46px;
        background-color: white;
    }
    
    .submit-btn {
        background-color: #4CAF50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        width: 100%;
        margin-top: 10px;
        transition: background-color 0.3s;
    }
    
    .submit-btn:hover {
        background-color: #45a049;
    }
    
    .message {
        text-align: center;
        padding: 15px;
        margin: 20px auto;
        border-radius: 5px;
        max-width: 500px;
        font-weight: 500;
    }
    
    .success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    
    .service-info {
        background-color: #e9f7ef;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 25px;
        text-align: center;
        border-left: 4px solid #4CAF50;
    }
    
    .service-info h3 {
        margin-top: 0;
        color: #2e7d32;
    }
    
    .service-info p {
        margin-bottom: 0;
        font-size: 18px;
        font-weight: bold;
    }
    
    .form-row {
        display: flex;
        gap: 15px;
        margin-bottom: 15px;
    }
    
    .form-row > div {
        flex: 1;
    }
    
    textarea {
        min-height: 100px;
        resize: vertical;
    }
    
    footer {
        background: #333;
        color: white;
        text-align: center;
        padding: 20px 0;
        margin-top: 40px;
        font-size: 14px;
    }
    
    @media (max-width: 768px) {
        .order-form {
            margin: 20px 15px;
            padding: 20px;
        }
        
        .form-row {
            flex-direction: column;
            gap: 0;
        }
        
        nav ul {
            flex-direction: column;
        }
        
        nav ul li {
            margin: 5px 0;
        }
    }
</style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="service.php">Services</a></li>
              
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="login.php">logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="order-form">
            <h2>book Service</h2>
            
            <?php if ($serviceType): ?>
            <div class="service-info">
                <h3><?php echo $serviceType; ?></h3>
                <p>Price: $<?php echo $servicePrice; ?></p>
            </div>
            <?php endif; ?>
            
            <form action="order.php" method="POST">
                <input type="hidden" name="serviceType" value="<?php echo $serviceType; ?>">
                <input type="hidden" name="servicePrice" value="<?php echo $servicePrice; ?>">
                
                <h3>Your Information</h3>
                <input type="text" name="name" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="tel" name="phone" placeholder="Phone Number" required>
                
                <h3>Appointment Time</h3>
                <div class="form-row">
                    <div>
                        <input type="date" name="appointmentDate" placeholder="Select Date" required>
                    </div>
                    <div>
                        <input type="time" name="appointmentTime" placeholder="Select Time" required>
                    </div>
                </div>
                
                <h3>Location Information</h3>
                <input type="text" name="clientLocation" placeholder="Your Location (Street, District,sector,cell)" required>
                
                <h3>Work Information</h3>
                <div class="form-row">
                    <div>
                        <select name="workContact" class="order-form">
                            <option value="">Select Work Contact</option>
                            <option value="Delphin">Name:Delphin <br>Tel:0790405655</option>
                            <option value="Patient">Name:Patient <br>Tel:0786414446</option>
                            <option value="Ritha">Name:Ritha <br>Tel:0793463570</option>
                        </select>
                    </div>
                </div>
                
                <h3>Vehicle Information</h3>
                <input type="text" name="carModel" placeholder="Car Model" required>
                <input type="text" name="carLicense" placeholder="License Plate Number" required>
                
                <h3>Additional Information</h3>
                <textarea name="specialInstructions" placeholder="Special instructions (optional)"></textarea>
             
                
                <button type="submit" class="submit-btn">Confirm Order</button>
            </form>
        </div>
    </main>

    <footer>
        <p>&copy; 2025 Shine Car Wash</p>
    </footer>
</body>
</html>