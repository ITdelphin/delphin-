<?php
$conn= mysqli_connect("localhost", "root", "", "shine_car_wash");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>