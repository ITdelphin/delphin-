<?php
// contact.php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars($_POST['phone']);
    $message = htmlspecialchars($_POST['message']);
    $contact_method = $_POST['contact_method'] ?? 'email';

    // Basic validation
    if (empty($name) || empty($message) || (empty($email) && empty($phone))) {
        $_SESSION['error'] = "Please provide at least one contact method and your message";
    } elseif ($contact_method == 'email' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Please enter a valid email address";
    } else {
        $to = "akezaritha12@gmail.com";
        $subject = "New Contact from Shine Car Wash Website";
        $headers = "From: $email\r\n";
        $headers .= "Reply-To: $email\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        
        $email_body = "Contact Method Preference: " . ucfirst($contact_method) . "\n\n";
        $email_body .= "Name: $name\n";
        if (!empty($email)) $email_body .= "Email: $email\n";
        if (!empty($phone)) $email_body .= "Phone: $phone\n";
        $email_body .= "\nMessage:\n$message\n";

        if (mail($to, $subject, $email_body, $headers)) {
            $_SESSION['message'] = "Thank you! Your message has been sent. We'll contact you via your preferred method.";
        } else {
            $_SESSION['error'] = "Failed to send message. Please try again later or call us directly.";
        }
    }
    header("Location: contact.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Shine Car Wash</title>
    <style>
        /* Main styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 1rem;
            text-align: center;
        }
        
        .nav {
            display: flex;
            justify-content: center;
            background-color: #34495e;
            padding: 0.5rem;
            flex-wrap: wrap;
        }
        
        .nav a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            margin: 0 0.5rem;
        }
        
        .nav a:hover {
            background-color: #3d566e;
            border-radius: 4px;
        }
        
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .contact-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 2rem;
            margin: 2rem auto;
            max-width: 800px;
        }
        
        .communication-options {
            display: flex;
            justify-content: space-around;
            margin: 2rem 0;
            flex-wrap: wrap;
        }
        
        .option-card {
            width: 30%;
            min-width: 250px;
            background: #f8f9fa;
            border-radius: 8px;
            padding: 1.5rem;
            margin: 0.5rem;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .option-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .option-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #3498db;
        }
        
        .contact-form {
            margin-bottom: 2rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        
        textarea {
            min-height: 150px;
        }
        
        .contact-method {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .contact-method input {
            width: auto;
            margin-right: 0.5rem;
        }
        
        .contact-method label {
            margin-bottom: 0;
            font-weight: normal;
        }
        
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }
        
        button:hover {
            background-color: #2980b9;
        }
        
        .contact-info {
            background-color: #f8f9fa;
            padding: 1.5rem;
            border-radius: 8px;
            margin-top: 2rem;
        }
        
        .phone-numbers {
            margin: 1rem 0;
        }
        
        .phone-numbers a {
            display: block;
            color: #3498db;
            text-decoration: none;
            margin: 0.5rem 0;
            font-size: 1.1rem;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }
        
        @media (max-width: 768px) {
            .option-card {
                width: 100%;
                margin-bottom: 1rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <h1>Shine Car Wash</h1>
    </header>
    
    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="book.php">Book Now</a>
        <a href="contact.php">Contact Us</a>
        <a href="login.php">lpogout</a>
    </nav>
    
    <div class="container">
        <div class="contact-container">
            <h2>How Would You Like to Communicate With Us?</h2>
            
            <div class="communication-options">
                <div class="option-card">
                    <div class="option-icon">📞</div>
                    <h3>By Phone</h3>
                    <p>Speak directly with our team for immediate assistance</p>
                    <div class="phone-numbers">
                        <a href="tel:+250790405655">0790 405 655</a>
                        <a href="tel:+250793463570">0793 463 570</a>
                        <a href="tel:+250733160155">0733 160 155</a>
                    </div>
                </div>
                
                <div class="option-card">
                    <div class="option-icon">✉️</div>
                    <h3>By Email</h3>
                    <p>Send us a detailed message and we'll respond promptly</p>
                    <a href="mailto:akezaritha12@gmail.com">akezaritha12@gmail.com</a>
                </div>
                
                <div class="option-card">
                    <div class="option-icon">📝</div>
                    <h3>Contact Form</h3>
                    <p>Fill out our form and we'll get back to you</p>
                </div>
            </div>
            
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['message']; ?></div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error"><?= $_SESSION['error']; ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
            
            <div class="contact-form">
                <h3>Send Us a Message</h3>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="name">Your Name:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Preferred Contact Method:</label>
                        <div class="contact-method">
                            <input type="radio" id="method-email" name="contact_method" value="email" checked>
                            <label for="method-email">Email</label>
                        </div>
                        <div class="contact-method">
                            <input type="radio" id="method-phone" name="contact_method" value="phone">
                            <label for="method-phone">Phone Call</label>
                        </div>
                    </div>
                    
                    <div class="form-group" id="email-group">
                        <label for="email">Your Email:</label>
                        <input type="email" id="email" name="email">
                    </div>
                    
                    <div class="form-group" id="phone-group" style="display: none;">
                        <label for="phone">Your Phone Number:</label>
                        <input type="tel" id="phone" name="phone">
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Your Message:</label>
                        <textarea id="message" name="message" required></textarea>
                    </div>
                    
                    <button type="submit">Send Message</button>
                </form>
            </div>
            
            <div class="contact-info">
                <h3>Business Hours</h3>
                <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                <p>Saturday: 9:00 AM - 4:00 PM</p>
                <p>Sunday: Closed</p>
                
                <h3>Location</h3>
                <p>Kigali, Rwanda</p>
                <p>Visit us at our physical location for immediate service</p>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <p>&copy; <?= date('Y'); ?> Shine Car Wash. All rights reserved.</p>
        <p>Contact us: 0790 405 655 | 0793 463 570 | 0733 160 155</p>
    </footer>

    <script>
        // Toggle contact method fields based on selection
        const emailRadio = document.getElementById('method-email');
        const phoneRadio = document.getElementById('method-phone');
        const emailGroup = document.getElementById('email-group');
        const phoneGroup = document.getElementById('phone-group');
        
        emailRadio.addEventListener('change', function() {
            if(this.checked) {
                emailGroup.style.display = 'block';
                phoneGroup.style.display = 'none';
                document.getElementById('email').setAttribute('required', '');
                document.getElementById('phone').removeAttribute('required');
            }
        });
        
        phoneRadio.addEventListener('change', function() {
            if(this.checked) {
                emailGroup.style.display = 'none';
                phoneGroup.style.display = 'block';
                document.getElementById('phone').setAttribute('required', '');
                document.getElementById('email').removeAttribute('required');
            }
        });
    </script>
</body>
</html>